import React, { useEffect, useState } from 'react';
import { Plus, Trash2, Edit, Eye, EyeOff, Link as LinkIcon, Upload, MoreHorizontal, Search, FileText, Download, X } from 'lucide-react';
import { getDownloadFileUrl, downloadFileDirect } from '../utils/media';
import '../css/DownloadPage.css';
import '../App.css';

export default function DownloadPage() {
  const [downloads, setDownloads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(true);

  // State Modal Form
  const [showModal, setShowModal] = useState(false);
  const [editId, setEditId] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    category: 'Kalender Akademik',
    description: '',
    url: '',
    file_size: '',
    sort_order: 1,
    show: 1
  });

  // 'url' = tempel link (boleh Google Drive), 'file' = upload berkas langsung (backend yang simpan ke Cloudinary)
  const [sourceType, setSourceType] = useState('url');
  const [selectedFile, setSelectedFile] = useState(null);
  const [submitting, setSubmitting] = useState(false); // true selama backend mengunggah berkas ke Cloudinary
  const [downloadingId, setDownloadingId] = useState(null); // id berkas yang sedang diunduh

  // State Dropdown & Search
  const [dropdownConfig, setDropdownConfig] = useState({ id: null, right: null, top: null, bottom: null });
  const [searchTerm, setSearchTerm] = useState('');

  const API_URL = 'https://smkn-compreng-api-pi.vercel.app/api/downloads';

  useEffect(() => {
    fetchDownloads();
  }, []);

  // Tutup dropdown saat scroll
  useEffect(() => {
    const handleScroll = () => {
      if (dropdownConfig.id !== null) {
        setDropdownConfig({ id: null, right: null, top: null, bottom: null });
      }
    };
    window.addEventListener('scroll', handleScroll, true);
    return () => window.removeEventListener('scroll', handleScroll, true);
  }, [dropdownConfig.id]);

  const fetchDownloads = async () => {
    try {
      setLoading(true);
      const res = await fetch(API_URL);
      const result = await res.json();
      if (result.success || Array.isArray(result)) {
        const rawData = result.data || result;
        const sortedData = rawData.sort((a, b) => {
          const orderA = a.sort_order ?? a.sortOrder ?? 99;
          const orderB = b.sort_order ?? b.sortOrder ?? 99;
          return orderA - orderB;
        });
        setDownloads(sortedData);
      }
    } catch (err) {
      console.error('Gagal mengambil data:', err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? (checked ? 1 : 0) : value
    }));
  };

  // Smart Dropdown Logic
  const handleDropdownClick = (e, downloadId) => {
    e.stopPropagation();
    if (dropdownConfig.id === downloadId) {
      setDropdownConfig({ id: null, right: null, top: null, bottom: null });
      return;
    }

    const rect = e.currentTarget.getBoundingClientRect();
    const windowHeight = window.innerHeight;
    const dropdownHeight = 140;
    
    const spaceBelow = windowHeight - rect.bottom;
    const openUpwards = spaceBelow < dropdownHeight;

    setDropdownConfig({
      id: downloadId,
      right: window.innerWidth - rect.right,
      top: openUpwards ? null : rect.bottom + 4,
      bottom: openUpwards ? windowHeight - rect.top + 4 : null
    });
  };

  const handleOpenModal = (item = null) => {
    setSelectedFile(null);
    if (item) {
      setEditId(item.id);
      setSourceType('url'); // saat edit, default tampilkan sebagai link (berkas lama tidak perlu diupload ulang)
      setFormData({
        title: item.title || '',
        category: item.category || 'Kalender Akademik',
        description: item.description || '',
        url: getDownloadFileUrl(item) || '',
        file_size: item.file_size || item.fileSize || '',
        sort_order: item.sort_order ?? item.sortOrder ?? 1,
        show: item.show ?? 1
      });
    } else {
      setEditId(null);
      setSourceType('url');
      const maxSortOrder = downloads.length > 0 ? Math.max(...downloads.map(d => d.sort_order ?? d.sortOrder ?? 0)) : 0;
      setFormData({
        title: '',
        category: 'Kalender Akademik',
        description: '',
        url: '',
        file_size: '',
        sort_order: maxSortOrder + 1,
        show: 1
      });
    }
    setShowModal(true);
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 20 * 1024 * 1024) {
        alert('Ukuran berkas maksimal 20 MB.');
        e.target.value = '';
        return;
      }
      setSelectedFile(file);
      setFormData((prev) => ({ ...prev, file_size: '' })); // biar diisi otomatis oleh backend sesuai ukuran asli
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (submitting) return;

    if (sourceType === 'url' && !formData.url) {
      alert('Silakan masukkan Link URL berkas terlebih dahulu!');
      return;
    }
    if (sourceType === 'file' && !selectedFile && !editId) {
      alert('Silakan pilih berkas yang akan diupload terlebih dahulu!');
      return;
    }

    try {
      setSubmitting(true);
      const url = editId ? `${API_URL}/${editId}` : API_URL;
      const method = editId ? 'PUT' : 'POST';

      // Dua metode, dua-duanya berakhir di Cloudinary (diproses backend):
      //  - Upload Berkas : berkas asli dikirim via FormData
      //  - Link URL      : link dikirim sebagai teks -> backend menyuruh Cloudinary mengambil berkas dari link itu
      // Yang disimpan ke database: secure_url + public_id Cloudinary (bukan base64).
      const fd = new FormData();
      fd.append('title', formData.title);
      fd.append('category', formData.category);
      fd.append('description', formData.description || '');
      fd.append('sort_order', Number(formData.sort_order));
      fd.append('sortOrder', Number(formData.sort_order));
      fd.append('show', Number(formData.show));
      fd.append('file_size', formData.file_size || '');

      if (sourceType === 'file' && selectedFile) {
        fd.append('file', selectedFile);
      } else {
        fd.append('url', formData.url || '');
      }

      const res = await fetch(url, { method, body: fd });
      const resData = await res.json();

      if (res.ok) {
        setShowModal(false);
        fetchDownloads();
      } else {
        alert(`Gagal: ${resData.message || 'Terjadi kesalahan'}`);
      }
    } catch (err) {
      console.error('Error saving data:', err);
      alert('Gagal terhubung ke server.');
    } finally {
      setSubmitting(false);
    }
  };

  // Unduh langsung, tanpa membuka tab/halaman baru
  const handleDownload = async (e, item) => {
    e.preventDefault();
    if (downloadingId) return;
    setDownloadingId(item.id);
    await downloadFileDirect(getDownloadFileUrl(item), item.title);
    setDownloadingId(null);
  };

  // Sembunyikan / Tampilkan langsung dari menu aksi (field yang dikirim sama persis dengan form Edit)
  const handleToggleShow = async (item) => {
    setDropdownConfig({ id: null, right: null, top: null, bottom: null });
    const newShow = Number(item.show) === 1 ? 0 : 1;
    try {
      const sortOrder = Number(item.sort_order ?? item.sortOrder ?? 1);
      const fd = new FormData();
      fd.append('title', item.title || '');
      fd.append('category', item.category || '');
      fd.append('description', item.description || '');
      fd.append('sort_order', sortOrder);
      fd.append('sortOrder', sortOrder);
      fd.append('show', newShow);
      fd.append('file_size', item.file_size || item.fileSize || '');
      fd.append('url', getDownloadFileUrl(item) || '');

      const res = await fetch(`${API_URL}/${item.id}`, { method: 'PUT', body: fd });
      if (res.ok) {
        fetchDownloads();
      } else {
        const resData = await res.json().catch(() => ({}));
        alert(`Gagal merubah status: ${resData.message || 'Terjadi kesalahan'}`);
      }
    } catch (err) {
      console.error('Error toggling show:', err);
      alert('Gagal terhubung ke server.');
    }
  };

  const handleDelete = async (id, title) => {
    setDropdownConfig({ id: null, right: null, top: null, bottom: null });
    if (window.confirm(`Apakah Anda yakin ingin menghapus berkas "${title || 'ini'}"?`)) {
      try {
        const res = await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
        if (res.ok) {
          fetchDownloads();
        } else {
          alert('Gagal menghapus data.');
        }
      } catch (err) {
        console.error('Error deleting:', err);
      }
    }
  };

  const visibleDownloads = isAdmin ? downloads : downloads.filter(d => d.show === 1);
  
  const filteredDownloads = visibleDownloads.filter(item => {
    const term = searchTerm.toLowerCase();
    return (
      (item.title || '').toLowerCase().includes(term) ||
      (item.category || '').toLowerCase().includes(term) ||
      (item.description || '').toLowerCase().includes(term)
    );
  });

  return (
    <div className="download-page mp-wrapper" id="admin-download">

      {/* Header Simpel */}
      <div className="simple-page-header">
        <div className="header-text-group">
          <h1 className="simple-main-title">Pusat Unduhan Sekolah</h1>
          <p className="simple-subtitle">
            Kelola berkas-berkas penting seputar akademik, kurikulum, dan administrasi sekolah di sini.
          </p>
        </div>
        {isAdmin && (
          <button className="btn-modern-primary dl-add-desktop" onClick={() => handleOpenModal()}>
            <Plus size={16} /> Tambah Berkas Baru
          </button>
        )}
      </div>

      {/* Search Bar */}
      <div className="simple-toolbar">
        <div className="mp-search-wrapper" style={{ width: '100%', maxWidth: '360px' }}>
          <Search size={16} className="mp-search-icon" />
          <input 
            type="text" 
            placeholder="Cari judul, kategori, atau deskripsi..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="mp-search-input"
          />
        </div>
        {/* Tombol ringkas khusus mobile: sebaris dengan Search (aksi sama dengan tombol desktop) */}
        {isAdmin && (
          <button type="button" className="btn-modern-primary dl-add-mobile" onClick={() => handleOpenModal()} aria-label="Tambah Berkas Baru">
            <Plus size={16} /> Tambah
          </button>
        )}
      </div>

      {/* Table Berkas */}
      <div className="mp-table-card dl-table-card">
        <table className="mp-table dl-table">
          <colgroup>
            <col className="dl-w1" />
            <col className="dl-w2" />
            <col className="dl-w3" />
            <col className="dl-w4" />
            <col className="dl-w5" />
            <col className="dl-w6" />
            {isAdmin && <col className="dl-w7" />}
          </colgroup>
          <thead>
            <tr>
              <th className="mp-th">Judul & Deskripsi Berkas</th>
              <th className="mp-th">Kategori</th>
              <th className="mp-th" style={{ textAlign: 'center' }}>Ukuran</th>
              <th className="mp-th" style={{ textAlign: 'center' }}>Urutan</th>
              <th className="mp-th">Status Tampil</th>
              <th className="mp-th" style={{ textAlign: 'center' }}>Unduh</th>
              {isAdmin && <th className="mp-th" style={{ textAlign: 'center' }}>Aksi</th>}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={isAdmin ? 7 : 6} style={{ textAlign: 'center', padding: '30px', color: 'var(--compreng-text-muted)' }}>
                  Memuat data berkas...
                </td>
              </tr>
            ) : filteredDownloads.length === 0 ? (
              <tr>
                <td colSpan={isAdmin ? 7 : 6} style={{ textAlign: 'center', padding: '40px', color: 'var(--compreng-text-muted)', fontSize: '13px' }}>
                  {searchTerm ? `Tidak ditemukan berkas dengan kata kunci "${searchTerm}"` : 'Belum ada berkas yang diunggah.'}
                </td>
              </tr>
            ) : (
              filteredDownloads.map((item) => (
                <tr key={item.id} className="mp-tr">
                  <td className="mp-td">
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <div style={{ width: '36px', height: '36px', borderRadius: '8px', backgroundColor: 'var(--compreng-surface-soft, #f1f5f9)', color: 'var(--compreng-accent, #2563eb)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <FileText size={20} />
                      </div>
                      <div>
                        <div style={{ fontWeight: '600', color: 'var(--compreng-text-main)' }}>{item.title}</div>
                        <div style={{ fontSize: '12px', color: 'var(--compreng-text-muted)', marginTop: '2px' }}>
                          {item.description || 'Tidak ada deskripsi.'}
                        </div>
                      </div>
                    </div>
                  </td>
                  
                  <td className="mp-td">
                    <span className="mp-badge-role" style={{ backgroundColor: 'var(--compreng-surface-soft, #f1f5f9)', color: 'var(--compreng-text-secondary, #475569)' }}>
                      {item.category || 'Lainnya'}
                    </span>
                  </td>

                  <td className="mp-td dl-td-nowrap" style={{ textAlign: 'center', fontSize: '13px', color: 'var(--compreng-text-secondary)' }}>
                    {item.file_size || item.fileSize || '-'}
                  </td>
                  
                  <td className="mp-td" style={{ textAlign: 'center', fontWeight: '600', color: 'var(--compreng-text-secondary)' }}>
                    {item.sort_order ?? item.sortOrder ?? '-'}
                  </td>
                  
                  <td className="mp-td">
                    <span className={`${item.show === 1 ? 'mp-badge-active dl-pill-on' : 'mp-badge-inactive dl-pill-off'} dl-pill`}>
                      {item.show === 1 ? 'Ditampilkan' : 'Disembunyikan'}
                    </span>
                  </td>
                  
                  <td className="mp-td dl-td-actions" style={{ textAlign: 'center' }}>
                    <div className="dl-actions" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <a 
                        href={getDownloadFileUrl(item)} 
                        onClick={(e) => handleDownload(e, item)}
                        download
                        className="btn-modern-secondary dl-unduh" 
                        style={{ padding: '6px 12px', fontSize: '12px', gap: '4px', textDecoration: 'none', opacity: downloadingId === item.id ? 0.6 : 1 }}
                      >
                        <Download size={14} /> {downloadingId === item.id ? 'Mengunduh...' : 'Unduh'}
                      </a>
                    </div>
                  </td>

                  {isAdmin && (
                    <td className="mp-td dl-td-actions" style={{ textAlign: 'center' }}>
                      <div className="dl-actions" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <button 
                          onClick={(e) => handleDropdownClick(e, item.id)}
                          className="mp-action-btn"
                          title="Opsi"
                        >
                          <MoreHorizontal size={18} />
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Tampilan Card List (mobile) - data & aksi sama dengan tabel */}
      <div className="dl-mlist">
        {loading ? (
          <div className="dl-mempty">Memuat data berkas...</div>
        ) : filteredDownloads.length === 0 ? (
          <div className="dl-mempty">
            {searchTerm ? `Tidak ditemukan berkas dengan kata kunci "${searchTerm}"` : 'Belum ada berkas yang diunggah.'}
          </div>
        ) : (
          filteredDownloads.map((item) => (
            <div key={item.id} className="dl-mcard">
              <div className="dl-mtop">
                <div className="dl-mfile"><FileText size={22} /></div>
                <div className="dl-mbody">
                  <div className="dl-mtitle">{item.title}</div>
                  <div className="dl-mdesc">{item.description || 'Tidak ada deskripsi.'}</div>
                </div>
                {isAdmin && (
                  <button
                    type="button"
                    onClick={(e) => handleDropdownClick(e, item.id)}
                    className="dl-mmore"
                    title="Opsi"
                  >
                    <MoreHorizontal size={18} />
                  </button>
                )}
              </div>
              <div className="dl-mmeta">
                <span className="dl-mchip dl-mchip-cat">{item.category || 'Lainnya'}</span>
                <span className="dl-mchip dl-mchip-info">{item.file_size || item.fileSize || '-'}</span>
                <span className="dl-mchip dl-mchip-info">Urutan {item.sort_order ?? item.sortOrder ?? '-'}</span>
                <span className={`dl-mchip ${item.show === 1 ? 'dl-mchip-on' : 'dl-mchip-off'}`}>
                  {item.show === 1 ? 'Ditampilkan' : 'Disembunyikan'}
                </span>
              </div>
              <a
                href={getDownloadFileUrl(item)}
                onClick={(e) => handleDownload(e, item)}
                download
                className="dl-mget"
                style={{ opacity: downloadingId === item.id ? 0.6 : 1 }}
              >
                <Download size={16} /> {downloadingId === item.id ? 'Mengunduh...' : 'Unduh Berkas'}
              </a>
            </div>
          ))
        )}
      </div>

      {/* DROPDOWN MENU OUTSIDE TABLE */}
      {dropdownConfig.id && (
        <>
          <div 
            onClick={() => setDropdownConfig({ id: null, right: null, top: null, bottom: null })} 
            style={{ position: 'fixed', inset: 0, zIndex: 40 }}
          ></div>
          
          <div 
            className="mp-dropdown-menu" 
            style={{ 
              position: 'fixed', 
              right: dropdownConfig.right, 
              ...(dropdownConfig.top !== null ? { top: dropdownConfig.top } : {}),
              ...(dropdownConfig.bottom !== null ? { bottom: dropdownConfig.bottom } : {}),
              zIndex: 50 
            }}
          >
            {(() => {
              const targetItem = downloads.find(t => t.id === dropdownConfig.id);
              if (!targetItem) return null;
              return (
                <>
                  <button onClick={() => handleToggleShow(targetItem)} className="mp-dropdown-item">
                    {Number(targetItem.show) === 1 ? <EyeOff size={14} color="var(--compreng-text-secondary)" /> : <Eye size={14} color="var(--compreng-text-secondary)" />}
                    {Number(targetItem.show) === 1 ? 'Sembunyikan' : 'Tampilkan'}
                  </button>
                  <button onClick={() => { setDropdownConfig({ id: null, right: null, top: null, bottom: null }); handleOpenModal(targetItem); }} className="mp-dropdown-item">
                    <Edit size={14} color="var(--compreng-text-secondary)" /> Edit Berkas
                  </button>
                  <div style={{ margin: '2px 0', borderTop: '1px solid var(--compreng-border)' }}></div>
                  <button onClick={() => handleDelete(targetItem.id, targetItem.title)} className="mp-dropdown-item danger">
                    <Trash2 size={14} color="currentColor" /> Hapus
                  </button>
                </>
              );
            })()}
          </div>
        </>
      )}

      {/* MODAL FORM SHADCN STYLE */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content modern-modal">
            <div className="modal-header-modern">
              <h3>{editId ? 'Edit Berkas' : 'Tambah Berkas Baru'}</h3>
              <button onClick={() => setShowModal(false)} className="btn-close-modal"><X size={20} /></button>
            </div>
            
            <form onSubmit={handleSubmit} className="form-modern-layout">
              <div className="form-group-modern">
                <label>Judul Berkas</label>
                <input 
                  type="text" 
                  name="title"
                  placeholder="Contoh: Kalender Akademik 2026/2027" 
                  className="input-modern" 
                  value={formData.title} 
                  onChange={handleChange} 
                  required 
                />
              </div>
              
              <div className="form-group-modern">
                <label>Kategori</label>
                <select 
                  name="category"
                  className="input-modern" 
                  value={formData.category} 
                  onChange={handleChange}
                >
                  <option value="Kalender Akademik">Kalender Akademik</option>
                  <option value="Kurikulum">Kurikulum</option>
                  <option value="Formulir">Formulir</option>
                  <option value="Jadwal Pelajaran">Jadwal Pelajaran</option>
                </select>
              </div>

              <div className="form-group-modern">
                <label>Deskripsi Singkat</label>
                <textarea 
                  name="description"
                  rows="3" 
                  placeholder="Tuliskan deskripsi singkat..." 
                  className="input-modern" 
                  style={{ resize: 'vertical' }}
                  value={formData.description} 
                  onChange={handleChange} 
                />
              </div>
              
              <div className="form-row-modern">
                <div className="form-group-modern" style={{ flex: 1 }}>
                  <label>Urutan Tampil (Angka)</label>
                  <input 
                    type="number" 
                    name="sort_order"
                    className="input-modern" 
                    value={formData.sort_order} 
                    onChange={handleChange} 
                    required 
                  />
                </div>
                <div className="form-group-modern" style={{ flex: 1 }}>
                  <label>Status Tampil</label>
                  <select 
                    name="show"
                    className="input-modern" 
                    value={formData.show} 
                    onChange={handleChange}
                  >
                    <option value={1}>Ditampilkan</option>
                    <option value={0}>Disembunyikan</option>
                  </select>
                </div>
              </div>

              {/* Sumber Berkas: Link URL (boleh Google Drive) ATAU Upload Berkas Langsung */}
              <div className="form-group-modern">
                <label>Sumber Berkas</label>
                <div style={{ display: 'flex', gap: '8px', marginBottom: '10px' }}>
                  <button
                    type="button"
                    onClick={() => setSourceType('url')}
                    className={sourceType === 'url' ? 'btn-modern-primary' : 'btn-modern-secondary'}
                    style={{ flex: 1, padding: '8px', fontSize: '13px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}
                  >
                    <LinkIcon size={14} /> Link URL
                  </button>
                  <button
                    type="button"
                    onClick={() => setSourceType('file')}
                    className={sourceType === 'file' ? 'btn-modern-primary' : 'btn-modern-secondary'}
                    style={{ flex: 1, padding: '8px', fontSize: '13px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}
                  >
                    <Upload size={14} /> Upload Berkas
                  </button>
                </div>

                {sourceType === 'url' ? (
                  <>
                    <input
                      type="url"
                      name="url"
                      placeholder="https://drive.google.com/file/... atau https://contoh.com/berkas.pdf"
                      className="input-modern"
                      value={formData.url}
                      onChange={handleChange}
                      required={sourceType === 'url'}
                    />
                    <small style={{ color: 'var(--compreng-text-muted)' }}>
                      {editId
                        ? 'Biarkan link apa adanya jika berkas tidak diganti.'
                        : 'Isi Berkas.'}
                    </small>
                  </>
                ) : (
                  <>
                    <input
                      type="file"
                      className="input-modern"
                      onChange={handleFileChange}
                    />
                    {editId && !selectedFile && (
                      <small style={{ color: 'var(--compreng-text-muted)' }}>
                        Kosongkan kalau tidak ingin mengganti berkas yang sudah ada.
                      </small>
                    )}
                    {selectedFile && (
                      <small style={{ color: 'var(--compreng-text-secondary)' }}>
                        Terpilih: {selectedFile.name}
                      </small>
                    )}
                  </>
                )}
              </div>

              <div className="form-group-modern">
                <label>Ukuran Berkas (Opsional)</label>
                <input 
                  type="text" 
                  name="file_size"
                  placeholder="Contoh: 1.2 MB (otomatis terisi kalau upload berkas)" 
                  className="input-modern" 
                  value={formData.file_size} 
                  onChange={handleChange} 
                  disabled={sourceType === 'file' && !!selectedFile}
                />
              </div>

              <div className="modal-actions-modern" style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '16px' }}>
                <button type="button" onClick={() => setShowModal(false)} className="btn-modern-secondary" disabled={submitting}>Batal</button>
                <button type="submit" className="btn-modern-primary" disabled={submitting}>
                  {submitting ? 'Mengunggah...' : 'Simpan Data'}
                </button>
              </div>
            </form>
            
          </div>
        </div>
      )}

    </div>
  );
}